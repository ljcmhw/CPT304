package assignment1;

import java.util.List;

public interface Book {
    public void SetBookName(String bookName);
    public void SetBookAuthor(String authorName);
    public void SetBookPrice(int price);
    public void SetBookTags(List<String> tags);
    public String GetBookName();
    public String GetAuthorName();
    public List<String> GetBookTags();
    public int GetBookPrice();
    public String GetBookType();
    public String DeleteTag(String tag);

}
