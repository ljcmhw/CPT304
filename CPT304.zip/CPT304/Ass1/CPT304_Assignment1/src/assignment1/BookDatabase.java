package assignment1;

public class BookDatabase extends Database<Book> {
    private FindBookStrategy findBookStrategy = new FindBookByName();
    private static class BookDatabaseHolder {
        private static BookDatabase instance = new BookDatabase();
    }
    public BookDatabase(){

    }
    public static BookDatabase getInstance(){
        return BookDatabaseHolder.instance;
    }
    @Override
    public Book Delete(Book book) {
        Book deletedBook = super.Delete(book);
        if(deletedBook==null){
            System.out.println("Didn't find "+book.toString());
            return null;
        }
        else
            return deletedBook;
    }

    public void SetFindBookStrategy(FindBookStrategy findBookStrategy){
        this.findBookStrategy = findBookStrategy;
    }

    public Book Find(String bookName) {
        return findBookStrategy.Find(getInstance(),bookName);
    }

}
