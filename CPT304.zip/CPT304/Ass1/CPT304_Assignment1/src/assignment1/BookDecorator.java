package assignment1;

import java.util.List;

public class BookDecorator implements Book {
    private Book book;
    protected BookDecorator(Book book){
        this.book = book;
    }
    @Override
    public void SetBookName(String bookName) {
        book.SetBookName(bookName);
    }

    @Override
    public void SetBookAuthor(String authorName) {
        book.SetBookAuthor(authorName);
    }

    @Override
    public void SetBookPrice(int price) {
        book.SetBookPrice(price);
    }

    @Override
    public void SetBookTags(List<String> tags) {
        book.SetBookTags(tags);
    }

    @Override
    public String GetBookName() {
        return book.GetBookName();
    }

    @Override
    public String GetAuthorName() {
        return book.GetAuthorName();
    }

    @Override
    public List<String> GetBookTags() {
        return book.GetBookTags();
    }

    @Override
    public int GetBookPrice() {
        return book.GetBookPrice();
    }
    @Override
    public String GetBookType(){ return book.GetBookType();}
    @Override
    public String DeleteTag(String tag) {
        return book.DeleteTag(tag);
    }
    public String toString(){ return book.toString();}
}
