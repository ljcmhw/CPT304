package assignment1;

public interface FindBookStrategy {
    Book Find(BookDatabase database, String Name);
}
