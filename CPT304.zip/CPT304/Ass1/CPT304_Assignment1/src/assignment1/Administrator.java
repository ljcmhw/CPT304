package assignment1;

public class Administrator implements User {
    private String name;
    private String password;
    public Administrator(String name, String password) {
        this.name = name;
        this.password = password;
    }

    @Override
    public String GetUserName() {
        return name;
    }
    public String GetPassword(){ return password;}

    @Override
    public Book FindBook(String bookName) {
        return BookDatabase.getInstance().Find(bookName);
    }

    @Override
    public String toString(){
        return "User name: "+ name + ", password: " + password;
    }
}
