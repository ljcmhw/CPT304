package assignment1;

import java.util.List;

public class FindBookByName implements FindBookStrategy{
    @Override
    public Book Find(BookDatabase database, String bookName) {
        List<Book> bookDatabase = database.GetDatabase();
        for(Book book : bookDatabase ){
            if(book.GetBookName().equals(bookName)){
                return book;
            }
        }
        return null;
    }
}
