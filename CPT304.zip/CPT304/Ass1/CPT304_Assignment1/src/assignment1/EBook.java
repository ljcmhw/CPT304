package assignment1;
import java.util.ArrayList;
import java.util.List;

// 基本图书类
public class EBook implements Book {
    private String name;
    private String authorName;
    private int price=0;
    private List<String> tags = new ArrayList<>();
    private String type = "E-Book";

    public EBook(){

    }

    public EBook(String name, String authorName, int price) {
        SetBookName(name);
        SetBookAuthor(authorName);
        SetBookPrice(price);
    }

    public EBook(String name, String authorName, int price, List<String> tags) {
        SetBookName(name);
        SetBookAuthor(authorName);
        SetBookPrice(price);
        SetBookTags(tags);
    }

    @Override
    public void SetBookName(String bookName) {
        this.name = bookName;
    }

    @Override
    public void SetBookAuthor(String authorName) {
        this.authorName = authorName;
    }

    @Override
    public void SetBookPrice(int price) {
        this.price = price;
    }

    @Override
    public void SetBookTags(List<String> tags) {
        this.tags = new ArrayList<>(tags);
    }

    @Override
    public String GetBookName() {
        return name;
    }

    @Override
    public String GetAuthorName() {
        return authorName;
    }
    @Override
    public int GetBookPrice() {
        return price;
    }

    @Override
    public List<String> GetBookTags() {
        return new ArrayList<>(tags);
    }
    @Override
    public String GetBookType(){ return type; }

    @Override
    public String DeleteTag(String tag) {
        if(tags.contains(tag)){
            return tags.remove((tags.indexOf(tag)));
        }
        return null;
    }
    @Override
    public String toString(){
        return "Name: " + name + ", Author: " + authorName + ", Price: " + price + ", Type: " + type;
    }
}

