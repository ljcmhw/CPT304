package assignment1;
public interface User {
    public String GetUserName();
    public String GetPassword();
    public Book FindBook(String bookName);
}
