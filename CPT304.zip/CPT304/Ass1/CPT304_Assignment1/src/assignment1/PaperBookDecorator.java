package assignment1;


public class PaperBookDecorator extends BookDecorator {

    private int fines=0;
    public PaperBookDecorator(Book book,int fines) {
        super(book);
        this.fines = fines;
    }
    public int GetFines(){
        return fines;
    }
    public String toString(){
        return super.toString()+" Additional fines: " + fines;
    }
}
