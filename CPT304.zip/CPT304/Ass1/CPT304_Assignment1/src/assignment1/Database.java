package assignment1;
import java.util.ArrayList;
import java.util.List;

public abstract class Database<T> {
    private final List<T> database = new ArrayList<>();

    protected Database() {
    }

    public void Add(T t){
        database.add(t);
    }
    public T Delete(T t){
        if(database.contains(t))
            return database.remove(database.indexOf(t));
        return null;
    }
    public List<T> GetDatabase(){
        return database;
    }
//    public abstract void Change(T t);

}
