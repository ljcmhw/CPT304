package assignment1;

import java.util.ArrayList;
import java.util.List;

// 基本图书类
public class PaperBook implements Book {
    private String name;
    private String authorName;
    private int price=0;
    private List<String> tags = new ArrayList<>();
    private boolean borrow = false;
    private String type = "Paper Book";

    public PaperBook(){

    }
    public PaperBook(String name, String authorName) {
        SetBookName(name);
        SetBookAuthor(authorName);
    }

    public PaperBook(String name, String authorName, int price) {
        SetBookName(name);
        SetBookAuthor(authorName);
        SetBookPrice(price);
    }

    public PaperBook(String name, String authorName, int price, List<String> tags) {
        SetBookName(name);
        SetBookAuthor(authorName);
        SetBookPrice(price);
        SetBookTags(tags);
    }
    public boolean BorrowBook(boolean borrow){
        if((borrow && !this.borrow) || (!borrow && this.borrow)){
            this.borrow = borrow;
            return true;
        }
        else{

            return false;
        }

    }
    @Override
    public void SetBookName(String bookName) {
        this.name = bookName;
    }

    @Override
    public void SetBookAuthor(String authorName) {
        this.authorName = authorName;
    }

    @Override
    public void SetBookPrice(int price) {
        this.price = price;
    }

    @Override
    public void SetBookTags(List<String> tags) {
        this.tags = new ArrayList<>(tags);
    }

    @Override
    public String GetBookName() {
        return name;
    }

    @Override
    public String GetAuthorName() {
        return authorName;
    }
    @Override
    public int GetBookPrice() {
        return price;
    }

    @Override
    public List<String> GetBookTags() {
        return new ArrayList<>(tags);
    }
    @Override
    public String GetBookType(){ return type; }

    @Override
    public String DeleteTag(String tag) {
        if(tags.contains(tag)){
            return tags.remove((tags.indexOf(tag)));
        }
        return null;
    }
    @Override
    public String toString(){
        if(borrow)
            return "Name: " + name + ", Author: " + authorName + ", Price: " + price + ", Type: " + type + " This book is borrowed.";
        else
            return "Name: " + name + ", Author: " + authorName + ", Price: " + price + ", Type: " + type;
    }
}

