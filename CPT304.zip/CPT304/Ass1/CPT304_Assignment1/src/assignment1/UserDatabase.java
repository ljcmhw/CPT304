package assignment1;
import java.util.List;

public class UserDatabase extends Database<User>{
    private static class UserDatabaseHolder {
        private static UserDatabase instance = new UserDatabase();
    }
    public UserDatabase(){

    }
    public static UserDatabase getInstance(){
        return UserDatabaseHolder.instance;
    }
    @Override
    public User Delete(User user) {
        User deletedUser= super.Delete(user);
        if(deletedUser==null){
            System.out.println("Didn't find "+user.toString());
            return null;
        }
        else
            return deletedUser;
    }
    public User Find(String userName,String password) {
        List<User> userDatabase = super.GetDatabase();
        for(User user : userDatabase ){
            if(user.GetUserName().equals(userName) && user.GetPassword().equals(password)){
                System.out.println(user);
                return user;
            }
        }
        return null;
    }

}
