package assignment1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 使用单例模式获取数据库实例
        BookDatabase bookDatabase = BookDatabase.getInstance();

        UserDatabase userDatabase = UserDatabase.getInstance();

        Book book1 = new PaperBook("C++", "Soon fei");
        Book book2 = new PaperBook("Java", "Erick");
        bookDatabase.Add(book1);
        bookDatabase.Add(book2);

        Scanner userInput = new Scanner(System.in);

        System.out.println("Registration");
        System.out.println("Name:");
        String userName = userInput.nextLine();
        System.out.println("Password:");
        String password = userInput.nextLine();
        User newUser = new Administrator(userName,password);
        if(userDatabase.Find(userName,password)==null){
            userDatabase.Add(newUser);
        }

        MainMenu(bookDatabase,userDatabase);
    }

    public static void MainMenu(BookDatabase bookDatabase, UserDatabase userDatabase){

        System.out.println(
                "Choose operation \n" +
                        "1: add book \n" +
                        "2: delete book \n" +
                        "3: show stored books \n" +
                        "4: show registered users \n" +
                        "5: borrow or return book \n" +
                        "6: add fines"
        );
        int command = GetCommand();
        switch (command) {
            case 1 -> AddBook(bookDatabase);
            case 2 -> {
                System.out.println("Delete a paper based book");
                DeleteBook(bookDatabase);
            }
            case 3 -> ShowStoredBooks(bookDatabase);
            case 4 -> ShowStoredUser(userDatabase);
            case 5 -> BorrowBook(bookDatabase);
            case 6 -> AddFines(bookDatabase);
            default -> System.out.println("Invalid Choice, please re-enter between 1 and 6");
        }
        MainMenu(bookDatabase,userDatabase);
    }

    public static void AddBook(BookDatabase bookDatabase){
        Scanner userInput = new Scanner(System.in);
        System.out.println("1: Add a paper book" +
                "2: Add an e-book");
        int command = GetCommand();
        Book book;
        if(command==1){
            book =new PaperBook();
        } else if (command == 2) {
            book =new EBook();
        }
        else{
            System.out.println("Please input valid number!");
            AddBook((bookDatabase));
            return;
        }
        System.out.println("Name: ");
        book.SetBookName(userInput.nextLine());
        System.out.println("Author: ");
        book.SetBookAuthor(userInput.nextLine());
        while(true){
            System.out.println("Price: ");
            try{
                int price = Integer.parseInt(userInput.nextLine());
                book.SetBookPrice(price);
                break;
            }
            catch(Exception e){
                System.out.println("Please input valid price!");
            }
        }
        bookDatabase.Add(book);
    }
    public static void DeleteBook(BookDatabase bookDatabase){
        Scanner userInput = new Scanner(System.in);
        System.out.println("1: Find book by book name" +
                "2: Find book by author");
        int command = GetCommand();
        switch (command) {
            case 1 -> {
                bookDatabase.SetFindBookStrategy(new FindBookByName());
                System.out.println("Target book name:");
                Book bookName = bookDatabase.Find(userInput.nextLine());
                if (bookName != null) {
                    bookDatabase.Delete(bookName);
                }
            }
            case 2 -> {
                bookDatabase.SetFindBookStrategy(new FindBookByAuthor());
                System.out.println("Target book author name:");
                Book authorName = bookDatabase.Find(userInput.nextLine());
                if (authorName != null) {
                    bookDatabase.Delete(authorName);
                }
            }
            default -> {
                System.out.println("Invalid Choice, please re-enter 1 or 2");
                DeleteBook(bookDatabase);
            }
        }
    }
    public static void ShowStoredBooks(BookDatabase bookDatabase){
        System.out.println("Stored books: ");
        for (Book book : bookDatabase.GetDatabase()) {
            System.out.println(book);
        }
    }
    public static void ShowStoredUser(UserDatabase userDatabase){
        System.out.println("Registered users: ");
        for(User user : userDatabase.GetDatabase()){
            System.out.println(user);
        }
    }
    public static void BorrowBook(BookDatabase bookDatabase){
        Scanner userInput = new Scanner(System.in);
        boolean borrow;
        System.out.println("1: Borrow book" +
                "2: Return book");
        int command = GetCommand();
        if(command==1){
            borrow = true;
        } else if (command==2) {
            borrow = false;
        }else{
            System.out.println("Please input valid number!");
            BorrowBook((bookDatabase));
            return;
        }
        System.out.println("Input book name: ");

        Book borrowBook = bookDatabase.Find(userInput.nextLine());
        boolean result = true;

        if(borrowBook == null){
            System.out.println("Please input correct book name");
            BorrowBook(bookDatabase);
            return;
        }
        if(borrowBook.GetBookType().equals("Paper Book")){
            result = ((PaperBook) borrowBook).BorrowBook(borrow);
        }
        if(result){
            System.out.println("Operation successful " + borrowBook);
        }
        else {
            System.out.println("You can not borrow or return the book");
        }
    }
    public static void AddFines(BookDatabase bookDatabase){
        Scanner userInput = new Scanner(System.in);
        System.out.println("Input book name: ");
        Book book = bookDatabase.Find(userInput.nextLine());
        if(book == null){
            System.out.println("Please input correct book name");
            AddFines(bookDatabase);
            return;
        }
        System.out.println("Input book fines: ");

        PaperBookDecorator bookWithFines = new PaperBookDecorator(book, GetCommand());
        System.out.println(book.GetBookName() + " Additional fines: " + bookWithFines.GetFines());
        bookDatabase.Delete(book);
        bookDatabase.Add(bookWithFines);
    }
    public static int GetCommand(){
        Scanner userInput = new Scanner(System.in);
        String input = userInput.nextLine();

        int cmd = 0;
        try {
            cmd = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number");
            cmd = GetCommand();
        }

        return cmd;
    }
}