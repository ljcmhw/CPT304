package assignment1;
import assignment1.BookDatabase;

import java.util.List;

public class FindBookByAuthor implements FindBookStrategy{
    @Override
    public Book Find(BookDatabase database, String authorName) {
        List<Book> bookDatabase = database.GetDatabase();
        for(Book book : bookDatabase ){
            if(book.GetAuthorName().equals(authorName)){
                return book;
            }
        }
        return null;
    }
}
